# Android Application like Instagram : 
  * Developed in Java Using Android Studio IDE.
  * Firebase is used in Authentication, real time database and storage.
  * Users can search for each other.
  * Follow and Unfollow feature is supported.
  * Users can like , comment , post and save photos of each other.
# Features :
  * Login Via Facebook account is supported.
  * Save posts.
  * Stories are supported with ability to show number of viewers and delete story .
  * Edit profile Settings.
  * Grid layout in profile.
  
